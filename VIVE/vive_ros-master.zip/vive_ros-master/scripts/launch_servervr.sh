#!/usr/bin/env bash

${STEAMVR}/bin/linux64/vrserver --keepalive
