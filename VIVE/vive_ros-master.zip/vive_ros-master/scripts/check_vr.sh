#!/usr/bin/env bash

${STEAMVR}/bin/linux64/vrcmd
