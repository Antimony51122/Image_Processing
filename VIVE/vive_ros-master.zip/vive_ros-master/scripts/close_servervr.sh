#!/usr/bin/env bash

killall -9 vrserver
